Font Family plugin for Atto
=========================

Based on atto_fontsize: Andrew Nicols and Adam Jenkins

https://github.com/andrewnicols/moodle-atto_fontsize

Requirements
============

- Moodle 2.7
- Moodle 2.8

Installation
============

* Place in lib/editor/atto/plugins
* Upgrade your Moodle
* Navigate to Site administration -> Plugins -> Text editors -> Atto HTML editor -> Atto toolbar settings
* Add the 'fontfamily' plugin in your location of choice
