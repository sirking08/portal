Horizontal Rule for Atto

QUICK INSTALL
=============
Put this entire directory at:

PATHTOMOODLE/lib/editor/atto/plugins/hr

Visit your site notifications page to install the new plugins.

Add the "hr" plugin to the Atto toolbar.
