# Edwiser Form Activity
This plugin allows you to add Edwiser form as activity in your course
