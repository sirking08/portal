<?php
$namespacetree = array(
	'std' => array(
		'vector' => array()
	)
);

$string = "char";