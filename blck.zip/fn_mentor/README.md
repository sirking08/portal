
    Name: NED - Mentor Manager
    Type: Block
    Moodle version required: 3.0 +
    For demo and documentation, go to http://ned.ca 
