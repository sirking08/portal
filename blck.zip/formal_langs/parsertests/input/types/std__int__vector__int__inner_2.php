<?php
$namespacetree = array(
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "std<int>::vector<2>::inner";