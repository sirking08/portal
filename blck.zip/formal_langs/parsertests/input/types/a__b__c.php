<?php
$namespacetree = array(
	'a' => array(
        'b' => array(
            'c' => array(
            
            )
        )
	)
);

$string = "a::b::c";