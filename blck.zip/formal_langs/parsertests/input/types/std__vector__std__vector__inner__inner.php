<?php
$namespacetree = array(
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "std::vector<std::vector<int*, std&*>::inner >::inner<2>";