<?php
$namespacetree = array(
	'a' => array(
	)
);

$string = "int (a::*f)(double, double) = &a::m;";