<?php
$namespacetree = array(
	'vector' => array(
        
	),
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "namespace A { namespace B { namespace C  { class D { }; }}} A::B::C::D k;";