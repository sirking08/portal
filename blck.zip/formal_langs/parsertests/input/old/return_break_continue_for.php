<?php
$namespacetree = array(
	'vector' => array(
        
	),
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "for(a = 3; a < 100; a++) { if (a == 25) continue; if (a == b) break; return 22; return; }";