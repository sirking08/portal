<?php
$namespacetree = array(
	'vector' => array(
        
	),
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "label: int a = 2; if (b < 0) goto exit; printf(\"%d\", 22); goto label; exit: return 0;";