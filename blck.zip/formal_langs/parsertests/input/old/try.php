<?php
$namespacetree = array(
	'vector' => array(
        
	),
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "typedef int Exception; try { a = unescaped_call(); } catch(Exception ex) { int a = 2;} catch(...) {}";