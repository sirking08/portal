<?php
$namespacetree = array(
	'vector' => array(
        
	),
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "for(i=0; i < 2; i++)
{
	
}
for(int i = 0; ;)
{
	
}
for(; ;)
{
	
}
";