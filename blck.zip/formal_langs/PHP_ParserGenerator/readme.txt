How to generate parser.
1)Put path to file with grammar in line 4111 in Main.php file.
2)Run Main.php file.
Generated file will be placed in the folder of the grammar file and named the same as the grammar file but with extension .php
