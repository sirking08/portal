This plugin is created to provide the form builder functionality in moodle LMS.
